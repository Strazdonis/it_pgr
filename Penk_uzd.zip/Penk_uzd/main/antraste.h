#include <stdio.h>

int ieska(int, int, int, int);

int isvestis(int, int);
